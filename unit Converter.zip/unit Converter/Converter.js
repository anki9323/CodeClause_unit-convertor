//length convetor//
let foot    =document.getElementById("foot");
let meter   =document.getElementById("meter");
let inch    =document.getElementById("inches");
let cm      =document.getElementById("cm");
let yard    =document.getElementById("yards");
let km      =document.getElementById("km");
let mile    =document.getElementById("miles");
//Area convetor//
let acre    =document.getElementById("acre");
let hectare   =document.getElementById("hectare");
let square_foot    =document.getElementById("square_foot");
let square_inch      =document.getElementById("square_inch");
let square_yard    =document.getElementById("square_yard");
let square_km      =document.getElementById("square_km");
let square_mile    =document.getElementById("square_mile");
let square_meter    =document.getElementById("square_meter");
//Volume convetor//
let cubic_meter    =document.getElementById("cubic_meter");
let cubic_kilometer   =document.getElementById("cubic_kilometer");
let cubic_centimeter    =document.getElementById("cubic_centimeter");
let cubic_milimeter      =document.getElementById("cubic_milimeter");
let liter    =document.getElementById("liter");
let milliliter      =document.getElementById("milliliter");
let US_gallaon    =document.getElementById("US_gallaon");
let us_quart    =document.getElementById("us_quart");
let us_teaspoon      =document.getElementById("us_teaspoon");
let us_tablespoon    =document.getElementById("us_tablespoon");
let cubic_foot    =document.getElementById("cubic_foot");
let cubic_inch    =document.getElementById("cubic_inch");
//Weight convetor//
let kilogram    =document.getElementById("kilogram");
let Gram        =document.getElementById("Gram");
let milligram   =document.getElementById("milligram");
let metric_ton  =document.getElementById("metric_ton");
let Long_ton    =document.getElementById("Long_ton");
let short_ton   =document.getElementById("short_ton");
let pound       =document.getElementById("pound");
let ounce       =document.getElementById("ounce");
let carrat      =document.getElementById("carrat");
let Atomic_mass_Unit =document.getElementById("Atomic_mass_Unit");
//Time convetor//
let Second    =document.getElementById("Second");
let Millisecond        =document.getElementById("Millisecond");
let Microsecond   =document.getElementById("Microsecond");
let Nanosecond  =document.getElementById("Nanosecond");
let picosecond  =document.getElementById("picosecond");
let Minute    =document.getElementById("Minute");
let Hour   =document.getElementById("Hour");
let Day       =document.getElementById("Day");
let week       =document.getElementById("week");
let Month      =document.getElementById("Month");
let year =document.getElementById("year");

// *********Length************ //

function footToOther(val){
    meter.value =  val/3.2808; 
    inch.value =  val*12;   
    cm.value    =  val/0.032808; 
    yard.value  =  val*0.33333;  
    km.value    =  val/3280.8; 
    mile.value  =  val*0.00018939;
}
function meterToOther(val){
    foot.value = val*3.2808;
    inch.value = val*39.370;  
    cm.value   = val/0.01;
    yard.value = val*1.0936; 
    km.value   = val/1000;
    mile.value = val*0.00062137;
}
function inchesToOther(val){
    foot.value = val*0.083333;
    meter.value = val/39.370;  
    cm.value = val/0.39370;
    yard.value = val*0.027778; 
    km.value = val/39370;
    mile.value = val*0.000015783;
}
function cmToOther(val){
    foot.value = val*0.032808;
    meter.value = val/100;  
    inch.value = val*0.39370;
    yard.value = val*0.010936; 
    km.value = val/100000 ;
    mile.value = val*0.0000062137;
}
function yardsToOther(val){
    foot.value = val*3;
    inch.value = val*36;  
    cm.value = val/0.010936;
    meter.value = val/1.0936; 
    km.value = val/1093.6;
    mile.value = val*0.00056818;}
function kmToOther(val){
    foot.value = val*3280.8;
    inch.value = val*39370;  
    cm.value = val*100000;
    yard.value = val*1093.6; 
    meter.value = val*1000;
    mile.value = val*0.62137;0,000;
}
function milesToOther(val){
    foot.value = val*5280;
    inch.value = val*63360;  
    cm.value = val/0.0000062137;
    yard.value = val*1760; 
    km.value = val/0.62137;
    meter.value = val/0.00062137;;

}


// **********Area***********//

function acreToOther(val){
    hectare.value = val*0.404686; 
    square_foot.value =  val*43560;   
    square_inch.value    =  val*6.273e6; 
    square_yard.value  =  val*4840;
    square_km.value    =  val*0.00404686;
    square_mile.value  =  val*0.0015625;
    square_meter.value = val*4046.86;
}
function hectareToOther(val){
    acre.value = val*2.47105;
    square_foot.value = val*107639;  
    square_inch.value   = val*1.55e7;
    square_yard.value = val*11959.9; 
    square_km.value   = val*0.01;
    square_mile.value = val*0.00386102;
    square_meter.value = val*10000;
}
function square_footToOther(val){
    acre.value = val*2.2957e-5;
    hectare.value = val*9.2903e-6;  
    square_inch.value = val*144;
    square_yard.value = val*0.111111; 
    square_km.value = val*9.2903e-8;
    square_mile.value = val*3.587e-8;
    square_meter.value = val*0.092903;
}
function square_inchToOther(val){
    acre.value = val*1.5942e-7;
    hectare.value = val*6.4516e-8;
    square_foot.value = val*0.00694444;
    square_yard.value = val*0.000771605;
    square_km.value = val*6.4516e-10;
    square_mile.value = val*2.491e-10;
    square_meter.value = val*0.00064516;
    
}
function square_yardToOther(val){
    acre.value = val*0.000206612;
    square_foot.value = val*9; 
    square_inch.value = val*1296;
    hectare.value = val*8.3613e-5;
    square_km.value = val*8.3613e-7;
    square_mile.value = val*3.2283e-7;
    square_meter.value = val*0.836127;
}
function square_kmToOther(val){
    acre.value = val*247.105;
    square_foot.value = val*1.076e7;  
    square_inch.value = val*1.55e9;
    square_yard.value = val*1.196e6;
    hectare.value = val*100;
    square_mile.value = val*0.386102;
    square_meter.value = val*1e6;
}
function square_mileToOther(val){
    acre.value = val*640;
    square_foot.value = val*2.788e7; 
    square_inch.value = val*4.014e9;
    square_yard.value = val*3.098e6;
    square_km.value = val*2.58999;
    hectare.value = val*258.999;
    square_meter.value = val*2.59e6;

}
function square_meterToOther(val){
    acre.value = val* 0.000247105;
    square_foot.value = val* 10.7639;
    square_inch.value = val* 1550;
    square_yard.value = val* 1.19599;
    square_km.value = val* 1e-6;
    hectare.value = val* 1e-4;
    square_mile.value = val* 3.861e-7;

}

// **********Volume***********//

function cubic_meterToOther(val){
    cubic_kilometer.value = val*1e-9;
    cubic_centimeter.value =  val*1000000; 
    cubic_milimeter.value    =  val*1e+9;
    liter.value  =  val*1000;
    milliliter.value    =  val*1e+6;
    US_gallaon.value  =  val*264.172;
    us_quart.value = val*1056.69;
    us_teaspoon.value    =  val*202884;
    us_tablespoon.value  =  val*67628;
    cubic_foot.value = val*35.3147;
    cubic_inch.value = val*61023.7;
}
function cubic_kilometerToOther(val){
    cubic_meter.value = val*1e+9;
    cubic_centimeter.value = val*1e+15;  
    cubic_milimeter.value   = val*1e+18;
    liter.value = val*1e+12; 
    milliliter.value   = val*1e+15;
    US_gallaon.value = val*2.642e+11;
    us_quart.value = val*1.057e+12;
    us_teaspoon.value    =  val*2.029e+14;
    us_tablespoon.value  =  val*6.763e+13;
    cubic_foot.value = val*3.531e+10;
    cubic_inch.value = val*6.102e+13;
}
function cubic_centimeterToOther(val){
    cubic_meter.value = val*1e-6;
    cubic_kilometer.value = val*1e-15;  
    cubic_milimeter.value = val*1000;
    liter.value = val*0.001; 
    milliliter.value = val*1;
    US_gallaon.value = val*0.000264172;
    us_quart.value = val*0.00105669;
    us_teaspoon.value    =  val*0.202884;
    us_tablespoon.value  =  val*0.067628;
    cubic_foot.value = val*3.5315e-5;
    cubic_inch.value = val*0.0610237;
}
function cubic_milimeterToOther(val){
    cubic_meter.value = val*1e-9;
    cubic_kilometer.value = val*1e-18;
    cubic_centimeter.value = val*0.001;
    liter.value = val*1e-6;
    milliliter.value = val*0.001;
    US_gallaon.value = val*2.6417e-7;
    us_quart.value = val*1.0567e-6;
    us_teaspoon.value    =  val*0.000202884;
    us_tablespoon.value  =  val*6.7628e-5;
    cubic_foot.value = val*3.5315e-8;
    cubic_inch.value = val*6.1024e-5;
}
function literToOther(val){
    cubic_meter.value = val*0.001;
    cubic_milimeter.value = val*1e+6;
    cubic_kilometer.value = val*1e-12;
    milliliter.value = val*1000;
    US_gallaon.value = val*0.264172;
    us_quart.value = val*1.05669;
    us_teaspoon.value    =  val*202.884;
    us_tablespoon.value  =  val*67.628;
    cubic_foot.value = val*0.0353147;
    cubic_inch.value = val*61.0237;
}
function milliliterToOther(val){
    cubic_meter.value = val*1e-6;
    cubic_centimeter.value = val*1;  
    cubic_milimeter.value = val*1000;
    liter.value = val*0.001;
    cubic_kilometer.value = val*1e-15;
    US_gallaon.value = val*0.000264172;
    us_quart.value = val*0.00105669;
    us_teaspoon.value    =  val*0.202884;
    us_tablespoon.value  =  val*0.067628;
    cubic_foot.value = val*3.5315e-5;
    cubic_inch.value = val*0.0610237;
}
function US_gallaonToOther(val){
    cubic_meter.value = val*0.00378541;
    cubic_centimeter.value = val*3785.41; 
    cubic_milimeter.value = val*3.785e+6;
    liter.value = val*3.78541;
    milliliter.value = val*3785.41;
    cubic_kilometer.value = val*3.7854e-12;
    us_quart.value = val*4;
    us_teaspoon.value    =  val*768;
    us_tablespoon.value  =  val*256;
    cubic_foot.value = val*0.133681;
    cubic_inch.value = val*231;

}
function us_quartToOther(val){
    cubic_meter.value = val* 0.000946353;
    cubic_centimeter.value = val* 946353;
    cubic_milimeter.value = val* 1550;
    liter.value = val* 0.946353;
    milliliter.value = val* 946.353;
    cubic_kilometer.value = val* 9.46353e-13;
    US_gallaon.value = val* 0.25;
    us_teaspoon.value    =  val*192;
    us_tablespoon.value  =  val*64;
    cubic_foot.value = val*0.0334201;
    cubic_inch.value = val*57.75;
}

function us_teaspoonToOther(val){
    cubic_meter.value = val*4.9289e-6;
    cubic_centimeter.value = val* 4.92892;
    cubic_milimeter.value = val* 4928.92;
    liter.value = val* 0.00492892;
    milliliter.value = val* 4.92892;
    cubic_kilometer.value = val* 4.92892e-15;
    US_gallaon.value = val*0.00130208;
    us_quart.value = val*0.00520833;
    us_tablespoon.value  =  val*0.333333;
    cubic_foot.value = val*0.000174063;
    cubic_inch.value = val*0.300781;
}
function us_tablespoonToOther(val){
    cubic_meter.value = val*1.4787e-5;
    cubic_centimeter.value = val* 14.7868;
    cubic_milimeter.value = val* 14786.8;
    liter.value = val* 0.0147868;
    milliliter.value = val* 14.7868;
    cubic_kilometer.value = val* 1.4787e-14;
    US_gallaon.value = val*0.00390625;
    us_quart.value = val*0.015625;
    us_teaspoon.value    =  val*3;
    cubic_foot.value = val*0.00052219;
    cubic_inch.value = val*0.902344;

}
function cubic_footToOther(val){
    cubic_meter.value = val*0.0283168;
    cubic_centimeter.value = val* 28316.8;
    cubic_milimeter.value = val* 2.832e+7;
    liter.value = val* 28.3168;
    milliliter.value = val* 28316.8;
    cubic_kilometer.value = val* 2.8317e-11;
    US_gallaon.value = val*7.48052;
    us_quart.value = val*29.9221;
    us_teaspoon.value    =  val*5745.04;
    us_tablespoon.value  =  val*1915.01;
    cubic_inch.value = val*1728;

}
function cubic_inchToOther(val){
    cubic_meter.value = val*1.6387e-5;
    cubic_centimeter.value = val* 16.3871;
    cubic_milimeter.value = val* 16387.1;
    liter.value = val* 0.0163871;
    milliliter.value = val* 16.3871;
    cubic_kilometer.value = val* 1.63871e-14;
    US_gallaon.value = val*0.004329;
    us_quart.value = val*0.017316;
    us_teaspoon.value    =  val*3.32468;
    us_tablespoon.value  =  val*1.10823;
    cubic_foot.value = val*0.000578704;

}
// **********Weight***********//

function kilogramToOther(val){
    Gram.value = val*1000;
    milligram.value =  val*1e+6;
    metric_ton.value    =  val*0.001;
    Long_ton.value  =  val*0.000984207;
    short_ton.value    =  val*0.00110231;
    pound.value  =  val*2.20462;
    ounce.value = val*35.274;
    carrat.value    =  val*5000;
    Atomic_mass_Unit.value  =  val*6.022e+26;
}
function GramToOther(val){
    kilogram.value = val* 0.001;
    milligram.value = val*1000;  
    metric_ton.value   = val*0.000001;
    Long_ton.value = val*9.842073304E-7; 
    short_ton.value   = val*0.0000011023;
    pound.value = val*0.0022046244;
    ounce.value = val*0.0352739907;
    carrat.value    =  val*5;
    Atomic_mass_Unit.value  =  val*6.022136652E+233;
}
function milligramToOther(val){
    kilogram.value = val*0.000001;
    Gram.value = val*0.001;  
    metric_ton.value = val*9.999999999E-10;
    Long_ton.value = val*9.842073304E-10; 
    short_ton.value = val*1.10231221E-9;
    pound.value = val*0.0000022046;
    ounce.value = val*0.000035274;
    carrat.value    =  val*0.005;
    Atomic_mass_Unit.value  =  val*602213665200000000000;
}
function metric_tonToOther(val){
    kilogram.value = val*1000;
    Gram.value = val*1000000;
    milligram.value = val*1000000000;
    Long_ton.value = val*0.9842073304;
    short_ton.value = val*1.1023122101;
    pound.value = val*2204.6244202;
    ounce.value = val*35273.990723;
    carrat.value    =  val*5000000;
    Atomic_mass_Unit.value  =  val*6.022136652E+29;
}
function Long_tonToOther(val){
    kilogram.value = val*1016.04608;
    Gram.value = val*1016046.08;
    milligram.value = val*1016046080; 
    metric_ton.value = val*1.01604608;
    short_ton.value = val*1.12;
    pound.value = val*2240;
    ounce.value = val*35840;
    carrat.value    =  val*5080230.4;
    Atomic_mass_Unit.value  =  val*6.118768338E+29;
}
function short_tonToOther(val){
    kilogram.value = val*907.184;
    Gram.value = val*907184;
    milligram.value = val*907184000;  
    metric_ton.value = val*0.907184;
    Long_ton.value = val*0.8928571429;
    pound.value = val*2000;
    ounce.value = val*32000;
    carrat.value    =  val*4535920;
    Atomic_mass_Unit.value  =  val*5.463186016E+29;

}
function poundToOther(val){
    kilogram.value = val*0.453592;
    Gram.value = val*453.592;
    milligram.value = val*453592; 
    metric_ton.value = val*0.000453592;
    Long_ton.value = val*0.0004464286;
    short_ton.value = val*0.0005;
    ounce.value = val*16;
    carrat.value    =  val*2267.96;
    Atomic_mass_Unit.value  =  val*2.731593008E+26;

}
function ounceToOther(val){
    kilogram.value = val* 0.0283495;
    Gram.value = val* 28.3495;
    milligram.value = val*28349.5;
    metric_ton.value = val* 0.0000283495;
    Long_ton.value = val*0.0000279018;
    short_ton.value = val*0.00003125;
    pound.value = val*0.0625;
    carrat.value    =  val*141.7475;
    Atomic_mass_Unit.value  =  val*1.70724563E+25;
}
function carratToOther(val){
    kilogram.value = val*0.0002;
    Gram.value = val* 0.0002;
    milligram.value = val* 200;
    metric_ton.value = val* 2.E-7;
    Long_ton.value = val* 1.96841466E-7;
    short_ton.value = val* 2.20462442E-7;
    pound.value = val*0.0004409249;
    ounce.value = val*0.0070547981;
    Atomic_mass_Unit.value  =  val*1.20442733E+23;
}
function Atomic_mass_UnitToOther(val){
    kilogram.value = val*1.660540199E-27;
    Gram.value = val* 1.660540199E-24;
    milligram.value = val* 1.660540199E-21;
    metric_ton.value = val*1.660540199E-30;
    Long_ton.value = val*1.634315837E-30;
    short_ton.value = val*1.830433737E-30;
    pound.value = val*3.660867475E-27;
    ounce.value = val*5.85738796E-26;
    carrat.value    =  val*8.302700999E-24;

}
// *********Time************ //
function SecondToOther(val){
    Millisecond.value = val*1000;
    Microsecond.value =  val*1000000;
    Nanosecond.value    =  val*1000000000;
    picosecond.value    =  val*1000000000000;
    Minute.value  =  val*0.0166666667;
    Hour.value    =  val*0.0002777778;
    Day.value  =  val*0.0000115741;
    week.value = val*0.0000016534;
    Month.value    =  val*3.802570537E-7;
    year.value  =  val*3.168808781E-8;
}
function MillisecondToOther(val){
    Second.value = val* 0.001;
    Microsecond.value = val*1000;
    Nanosecond.value    =  val*1000000;  
    picosecond.value   = val*1000000000;
    Minute.value = val*0.0000166667; 
    Hour.value   = val*2.777777777E-7;
    Day.value = val*1.157407407E-8;
    week.value = val*1.653439153E-9;
    Month.value    =  val*3.802570537E-10;
    year.value  =  val*3.168808781E-11;
}
function MicrosecondToOther(val){
    Second.value = val*0.000001;
    Millisecond.value = val*0.001;
    Nanosecond.value    =  val*1000;  
    picosecond.value = val*1000000;
    Minute.value = val*1.666666666E-8; 
    Hour.value = val*2.777777777E-10;
    Day.value = val*1.157407407E-11;
    week.value = val*1.653439153E-12;
    Month.value    =  val*3.802570537E-13;
    year.value  =  val*3.168808781E-14;
}
function NanosecondToOther(val){
    Second.value = val*1.E-9;
    Millisecond.value = val*0.000001;
    Microsecond.value = val*0.001;  
    picosecond.value = val*1000;
    Minute.value = val*1.666666666E-11; 
    Hour.value = val*2.777777777E-13;
    Day.value = val*1.157407407E-14;
    week.value = val*1.653439153E-15;
    Month.value    =  val*3.802570537E-16;
    year.value  =  val*3.168808781E-17;
}
function picosecondToOther(val){
    Second.value = val*1.E-12;
    Millisecond.value = val*1.E-9;
    Microsecond.value = val*0.000001;
    Nanosecond.value    =  val*0.001;
    Minute.value = val*1.666666666E-14;
    Hour.value = val*2.777777777E-16;
    Day.value = val*1.157407407E-17;
    week.value = val*1.653439153E-18;
    Month.value    =  val*3.802570537E-19;
    year.value  =  val*3.168808781E-20;
}
function MinuteToOther(val){
    Second.value = val*60;
    Millisecond.value = val*60000;
    Microsecond.value = val*60000000; 
    Nanosecond.value    =  val*60000000000;
    picosecond.value = val*60000000000000;
    Hour.value = val*0.0166666667;
    Day.value = val*0.0006944444;
    week.value = val*0.0000992063;
    Month.value    =  val*0.0000228154;
    year.value  =  val*0.0000019013;
}
function HourToOther(val){
    Second.value = val*3600;
    Millisecond.value = val*3600000;
    Microsecond.value = val*3600000000;
    Nanosecond.value    =  val*3600000000000;  
    picosecond.value = val*3600000000000000;
    Minute.value = val*60;
    Day.value = val*0.0416666667;
    week.value = val*0.005952381;
    Month.value    =  val*0.0013689254;
    year.value  =  val*0.0001140771;

}
function DayToOther(val){
    Second.value = val*86400;
    Millisecond.value = val*86400000;
    Microsecond.value = val*86400000000; 
    Nanosecond.value    =  val*86400000000000;
    picosecond.value = val*86400000000000000;
    Minute.value = val*1440;
    Hour.value = val*24;
    week.value = val*0.1428571429;
    Month.value    =  val*0.0328542094;
    year.value  =  val*0.0027378508;

}
function weekToOther(val){
    Second.value = val* 604800;
    Millisecond.value = val* 604800000;
    Microsecond.value = val*604800000000;
    Nanosecond.value    =  val*604800000000000;
    picosecond.value = val* 604800000000000000;
    Minute.value = val*10080;
    Hour.value = val*168;
    Day.value = val*7;
    Month.value    =  val*0.2299794661;
    year.value  =  val*0.0191649555;
}
function MonthToOther(val){
    Second.value = val*2629800;
    Millisecond.value = val*2629800000;
    Microsecond.value = val* 2629800000000;
    Nanosecond.value    =  val*2629800000000000;
    picosecond.value = val* 2629800000000000000;
    Minute.value = val* 43830;
    Hour.value = val* 730.5;
    Day.value = val*30.4375;
    week.value = val*4.3482142857;
    year.value  =  val*0.0833333333;
}
function yearToOther(val){
    Second.value = val*31557600;
    Millisecond.value = val* 31557600000;
    Microsecond.value = val* 31557600000000;
    Nanosecond.value    =  val*31557600000000000;
    picosecond.value = val*31557600000000000000
    Minute.value = val*525960;
    Hour.value = val*8766;
    Day.value = val*365.25;
    week.value = val*52.178571429;
    Month.value    =  val*12;

}

function convertToOthers(convertFrom,value)
{    
    switch(convertFrom){
        case "foot" : footToOther (parseFloat(value)); break;
        case "meter": meterToOther(parseFloat(value)); break;
        case "inch" : inchesToOther(parseFloat(value)); break;
        case "cm"   : cmToOther(parseFloat(value)); break;
        case "yard" : yardsToOther (parseFloat(value)); break;
        case "km"   : kmToOther (parseFloat(value)); break;
        case "mile" : milesToOther(parseFloat(value)); break;
        case "acre" : acreToOther (parseFloat(value)); break;
        case "hectare": hectareToOther(parseFloat(value)); break;
        case "square_foot" : square_footToOther(parseFloat(value)); break;
        case "square_inch"   : square_inchToOther(parseFloat(value)); break;
        case "square_yard" : square_yardToOther (parseFloat(value)); break;
        case "square_km"   : square_kmToOther (parseFloat(value)); break;
        case "square_mile" : square_mileToOther(parseFloat(value)); break;
        case "square_meter" : square_meterToOther(parseFloat(value)); break;
        case "cubic_meter" : cubic_meterToOther (parseFloat(value)); break;
        case "cubic_kilometer": cubic_kilometerToOther(parseFloat(value)); break;
        case "cubic_centimeter" : cubic_centimeterToOther(parseFloat(value)); break;
        case "cubic_milimeter"   : cubic_milimeterToOther(parseFloat(value)); break;
        case "liter" : literToOther (parseFloat(value)); break;
        case "milliliter"   : milliliterToOther (parseFloat(value)); break;
        case "US_gallaon" : US_gallaonToOther(parseFloat(value)); break;
        case "us_quart" : us_quartToOther(parseFloat(value)); break;
        case "us_teaspoon"   : us_teaspoonToOther (parseFloat(value)); break;
        case "us_tablespoon" : us_tablespoonToOther(parseFloat(value)); break;
        case "cubic_foot" : cubic_footToOther(parseFloat(value)); break;
        case "cubic_inch" : cubic_inchToOther(parseFloat(value)); break;
        case "kilogram" : kilogramToOther (parseFloat(value)); break;
        case "Gram": GramToOther(parseFloat(value)); break;
        case "milligram" : milligramToOther(parseFloat(value)); break;
        case "metric_ton"   : metric_tonToOther(parseFloat(value)); break;
        case "Long_ton" : Long_tonToOther (parseFloat(value)); break;
        case "short_ton"   : short_tonToOther(parseFloat(value)); break;
        case "pound" : poundToOther(parseFloat(value)); break;
        case "ounce" : ounceToOther(parseFloat(value)); break;
        case "carrat"   : carratToOther(parseFloat(value)); break;
        case "Atomic_mass_Unit" : Atomic_mass_UnitToOther(parseFloat(value)); break;
        case "Second" : SecondToOther (parseFloat(value)); break;
        case "Millisecond": MillisecondToOther(parseFloat(value)); break;
        case "Microsecond" : MicrosecondToOther(parseFloat(value)); break;
        case "Nanosecond" :NanosecondToOther(parseFloat(value)); break;
        case "picosecond"   : picosecondToOther(parseFloat(value)); break;
        case "Minute" : MinuteToOther (parseFloat(value)); break;
        case "Hour"   : HourToOther(parseFloat(value)); break;
        case "Day" : DayToOther(parseFloat(value)); break;
        case "week" : weekToOther(parseFloat(value)); break;
        case "Month"   : MonthToOther(parseFloat(value)); break;
        case "year" : yearToOther(parseFloat(value)); break;
    }
}




// temprature convertor//
const celciusInput = document.getElementById("celcius");
const fahrenheitInput = document.getElementById("fahrenheit");
const kelvinInput = document.getElementById("kelvin");

const inputs = document.getElementsByClassName("input");

for (let i = 0; i < inputs.length; i++) {
    let input = inputs[i];

    input.addEventListener("input", function (e) {
        let value = parseFloat(e.target.value);
        
        switch (e.target.name) {
            case "celcius":
                fahrenheitInput.value = (value * 1.8) + 32;
                kelvinInput.value = value + 273.15;
                break;
            case "fahrenheit":
                celciusInput.value = (value - 32) / 1.8;
                kelvinInput.value = ((value - 32) / 1.8) + 273.15;
                break;
            case "kelvin":
                celciusInput.value = value - 273.15;
                fahrenheitInput.value = ((value - 273.15) * 1.8) + 32;
                break;
        }
    });
}


